import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from '../frontend/user/pages/Home';
import About from '../frontend/user/pages/About';
import Services from '../frontend/user/pages/Services';
import PrivacyPolicy from '../frontend/user/pages/PrivacyPolicy';
import DeliveryPolicy from '../frontend/user/pages/DeliveryPolicy';
import TermsConditions from '../frontend/user/pages/TermsConditions';
import TrackOrder from '../frontend/user/pages/TrackOrder';
import Cart from '../frontend/user/pages/Cart';
import StoreLocator from '../frontend/user/pages/StoreLocator';
import Header from '../frontend/user/components/Header';
import Footer from '../frontend/user/components/Footer';
import AdminDashboard from '../frontend/admin/pages/Dashboard';
import ProtectedRoute from '../frontend/admin/components/auth/ProtectedRoute';

const App = () => {
  return (
    <Router>
      <div className="min-h-screen flex flex-col">
        <Routes>
          <Route path="/track-order" element={<TrackOrder />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/admin/*" element={
            <ProtectedRoute>
              <AdminDashboard />
            </ProtectedRoute>
          } />
          <Route
            path="/*"
            element={
              <>
                <Header />
                <main className="flex-grow">
                  <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/about" element={<About />} />
                    <Route path="/services" element={<Services />} />
                    <Route path="/store-locator" element={<StoreLocator />} />
                    <Route path="/privacy-policy" element={<PrivacyPolicy />} />
                    <Route path="/delivery-policy" element={<DeliveryPolicy />} />
                    <Route path="/terms-conditions" element={<TermsConditions />} />
                  </Routes>
                </main>
                <Footer />
              </>
            }
          />
        </Routes>
      </div>
    </Router>
  );
};

export default App;